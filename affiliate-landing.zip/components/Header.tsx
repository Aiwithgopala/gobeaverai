"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-white shadow-md py-2" : "bg-white/95 py-3"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <div className="flex items-center">
          <Image
            src="https://bitfan-id.s3.ap-northeast-1.amazonaws.com/store/c284adcd67b6be837474772e8d307eea.png"
            alt="Go Beaver AI Logo"
            width={160}
            height={40}
            className="h-10 w-auto"
          />
        </div>
        <Link
          href="https://jvz8.com/c/3297023/418161/"
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors duration-300 font-medium"
        >
          Get Bundle Now
        </Link>
      </div>
    </header>
  )
}
