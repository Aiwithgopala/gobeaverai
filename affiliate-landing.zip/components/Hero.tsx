import Link from "next/link"
import { ArrowRight } from "lucide-react"
import CountdownTimer from "./CountdownTimer"

export default function Hero() {
  return (
    <section className="py-12 md:py-20">
      <div className="text-center max-w-4xl mx-auto">
        <div className="mb-8 bg-gradient-to-r from-blue-100 to-green-100 p-4 rounded-lg inline-block">
          <p className="text-blue-800 font-medium">Nice! You've found the Exclusive Webinar Bundle Page - Save $200!</p>
          <div className="mt-2">
            <p className="text-gray-700 font-medium">Hurry - Coupon 'SAVE200' Expires Midnight P.S.T</p>
            <CountdownTimer />
          </div>
        </div>

        <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-green-600">
          Spy, Copy & Clone Winning Ads That Earn $2,472/Day
        </h1>
        <p className="text-lg md:text-xl text-gray-700 mb-8 max-w-3xl mx-auto">
          Using This NEW A.I Technology To Transform Your Marketing Campaigns
        </p>

        <div className="bg-white shadow-xl rounded-xl p-6 mb-8">
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="text-left">
              <p className="text-gray-500 text-lg">Regular Bundle Price</p>
              <p className="text-3xl font-bold text-gray-400 line-through">$497</p>
              <p className="text-sm text-green-600 font-medium mt-1">Use Coupon SAVE200</p>
            </div>
            <div className="text-center">
              <p className="text-gray-500 text-lg">Your Price Today</p>
              <p className="text-4xl font-bold text-green-600">Just $297</p>
              <p className="text-sm text-gray-600 font-medium mt-1">One Time Payment!</p>
            </div>
          </div>
        </div>

        <Link
          href="https://jvz8.com/c/3297023/418161/"
          className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg text-lg font-medium transition-all duration-300 transform hover:scale-105 flex items-center gap-2 w-full sm:w-auto justify-center mx-auto"
        >
          Get the Exclusive Webinar Bundle Now
          <ArrowRight className="h-5 w-5" />
        </Link>
        <p className="mt-4 text-gray-600 font-medium">No Monthly Fees EVER - One Time Payment</p>
      </div>
    </section>
  )
}
