import Image from "next/image"
import { Check } from "lucide-react"

export default function Features() {
  return (
    <section className="py-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">Your Exclusive Webinar Bundle Includes 4 Upgrades</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">TOTAL VALUE $3394!</p>
      </div>

      {/* Upgrade 1 */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-12">
        <div className="p-6 md:p-8">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/3">
              <div className="relative h-64 rounded-lg overflow-hidden">
                <Image
                  src="https://images.clickfunnels.com/cdn-cgi/image/width=2600,fit=scale-down,f=auto,q=80/https://statics.myclickfunnels.com/workspace/jQQdMW/image/13925130/file/63e5ba6a451382926771b5132b7fb4f2.png"
                  alt="Go Beaver AI - UNLIMITED"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
            <div className="md:w-2/3">
              <div className="flex items-center mb-4">
                <span className="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">Upgrade #1</span>
                <h3 className="text-2xl font-bold ml-3">Go Beaver A.I - UNLIMITED</h3>
              </div>
              <p className="text-gray-600 mb-4">Access to software - UNLIMITED! (Value $2394)</p>

              <h4 className="text-xl font-semibold mb-3">
                The Ultimate Ads, Social Media & Email Content Generation Tool On the Planet
              </h4>
              <p className="text-gray-700 mb-4">
                GoBeaver A.I can generate winning ads, social media posts and emails for any niche on the planet.
              </p>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h5 className="font-medium mb-3">Create Content For Multiple Platforms:</h5>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-white p-3 rounded-md text-center shadow-sm">FB Ads</div>
                  <div className="bg-white p-3 rounded-md text-center shadow-sm">Instagram</div>
                  <div className="bg-white p-3 rounded-md text-center shadow-sm">TikTok</div>
                  <div className="bg-white p-3 rounded-md text-center shadow-sm">YouTube</div>
                  <div className="bg-white p-3 rounded-md text-center shadow-sm">Google Search</div>
                  <div className="bg-white p-3 rounded-md text-center shadow-sm">Google Banner</div>
                  <div className="bg-white p-3 rounded-md text-center shadow-sm">LinkedIn</div>
                  <div className="bg-white p-3 rounded-md text-center shadow-sm">Email Marketing</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Upgrade 2 */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-12">
        <div className="p-6 md:p-8">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/3">
              <div className="relative h-64 rounded-lg overflow-hidden">
                <Image
                  src="https://images.clickfunnels.com/cdn-cgi/image/width=2600,fit=scale-down,f=auto,q=80/https://statics.myclickfunnels.com/workspace/jQQdMW/image/13925190/file/03e895ca6248ec357b17e2c545e4b73b.png"
                  alt="Go Beaver Super Spy"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
            <div className="md:w-2/3">
              <div className="flex items-center mb-4">
                <span className="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">Upgrade #2</span>
                <h3 className="text-2xl font-bold ml-3">Go Beaver Super Spy</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Spy direct from FB & TikTok ads library with chrome extension (Value $297)
              </p>

              <div className="space-y-3 mb-6">
                <div className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <p>Spy Direct On Facebook Ads Library On Your Competitors - Re Create Your Own with A.I In 1 Click</p>
                </div>
                <div className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <p>Spy Direct on TikTok Ads Library - Discover Winning Viral and Ads & Videos</p>
                </div>
                <div className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <p>Create A Month of Organic Social Media Posts In Minutes</p>
                </div>
                <div className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <p>Create Incredible Seasonal Campaigns Based of Your Competitors Winning Value</p>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h5 className="font-medium mb-3">Simple 3-Step Process:</h5>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white p-4 rounded-md shadow-sm">
                    <div className="font-bold text-blue-600 mb-2">Step 1</div>
                    <p className="text-sm">Spy on Any Keyword/Advertiser on Facebook Library</p>
                  </div>
                  <div className="bg-white p-4 rounded-md shadow-sm">
                    <div className="font-bold text-blue-600 mb-2">Step 2</div>
                    <p className="text-sm">Spy on Viral, Winning TikTok Video Ads And Re Create Your Own</p>
                  </div>
                  <div className="bg-white p-4 rounded-md shadow-sm">
                    <div className="font-bold text-blue-600 mb-2">Step 3</div>
                    <p className="text-sm">Publish your content to generate traffic, leads and sales!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Upgrade 3 */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-12">
        <div className="p-6 md:p-8">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/3">
              <div className="relative h-64 rounded-lg overflow-hidden">
                <Image
                  src="https://images.clickfunnels.com/cdn-cgi/image/width=2600,fit=scale-down,f=auto,q=80/https://statics.myclickfunnels.com/workspace/jQQdMW/image/13925208/file/9e4b00457ca386dd39cc4ee6bf593309.png"
                  alt="Go Beaver PRO Edition"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
            <div className="md:w-2/3">
              <div className="flex items-center mb-4">
                <span className="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">Upgrade #3</span>
                <h3 className="text-2xl font-bold ml-3">Go Beaver PRO Edition</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Included A.I Geniuses, seasonal promos and Social Beaver Organic social media (Value $297)
              </p>

              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-semibold mb-2">Pro Feature #1 - 12 A.I Geniuses</h4>
                  <p className="text-gray-700 mb-3">
                    Write Ads & Social Posts Like Your Favorite Guru or Expert. Our A.I Geniuses write your ad and
                    social posts in your favorite Guru's style!
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    <div className="bg-gray-50 p-3 rounded-md text-sm">Funnel Ad Genius</div>
                    <div className="bg-gray-50 p-3 rounded-md text-sm">Direct Response Ad Genius</div>
                    <div className="bg-gray-50 p-3 rounded-md text-sm">Entrepreneur</div>
                    <div className="bg-gray-50 p-3 rounded-md text-sm">Business Coaching</div>
                    <div className="bg-gray-50 p-3 rounded-md text-sm">Super Affiliate Ad Genius</div>
                    <div className="bg-gray-50 p-3 rounded-md text-sm">Real Estate Genius</div>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-semibold mb-2">
                    Pro Feature #2 - Instant Seasonal 'Done For You' Campaigns
                  </h4>
                  <p className="text-gray-700 mb-3">
                    Want to run a promotion for the big "money spending" periods of the year but never seem to have
                    enough time? This feature is PERFECT for you - Instant Campaigns in seconds.
                  </p>
                </div>

                <div>
                  <h4 className="text-lg font-semibold mb-2">Pro Feature #3 - 'Social Beaver A.I'</h4>
                  <p className="text-gray-700">
                    Create Amazing Organic Social Media With Social Beaver. In a few clicks you instantly can create
                    full social media campaigns.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Upgrade 4 */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="p-6 md:p-8">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/3">
              <div className="relative h-64 rounded-lg overflow-hidden">
                <Image
                  src="https://images.clickfunnels.com/cdn-cgi/image/width=2600,fit=scale-down,f=auto,q=80/https://statics.myclickfunnels.com/workspace/jQQdMW/image/13925314/file/a0bb9d33fd0a8ba31c91b175c61303d0.png"
                  alt="Go Beaver Super Affiliate DFY"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
            <div className="md:w-2/3">
              <div className="flex items-center mb-4">
                <span className="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">Upgrade #4</span>
                <h3 className="text-2xl font-bold ml-3">Go Beaver Super Affiliate DFY</h3>
              </div>
              <p className="text-gray-600 mb-4">Includes 25 DFY Super affiliate campaigns (Value $297)</p>

              <h4 className="text-lg font-semibold mb-3">25 Super Affiliate Campaigns</h4>
              <p className="text-gray-700 mb-4">
                Point, Click and Launch Campaigns Within Seconds. With Go Beaver's Super Affiliate Done-For-You
                25-Campaign Package, you take a giant leap ahead by having 25 hot, converting campaigns pre-loaded
                directly into your Beaver A.I account.
              </p>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h5 className="font-medium mb-3">What You Get Inside Each Campaign:</h5>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-sm">Expertly Crafted Facebook Ads</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-sm">Engaging Landing Page Copy</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-sm">Short-Style Promo Video</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-sm">High-Converting YouTube Scripts</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-sm">Attention-Grabbing TikTok Scripts</p>
                  </div>
                  <div className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-sm">Powerful Email Follow-Up Sequence</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
