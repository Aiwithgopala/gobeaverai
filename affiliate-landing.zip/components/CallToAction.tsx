import Link from "next/link"
import { ArrowRight, ShieldCheck } from "lucide-react"

export default function CallToAction() {
  return (
    <section className="py-16">
      {/* Money Back Guarantee */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-12 p-6 md:p-8">
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="md:w-1/4 flex justify-center">
            <div className="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center">
              <ShieldCheck className="w-16 h-16 text-blue-600" />
            </div>
          </div>
          <div className="md:w-3/4">
            <h3 className="text-2xl font-bold mb-4">Your Covered By Our 'No Quibble' 30 Day Money Back Guarantee</h3>
            <p className="text-gray-700 mb-4">
              At Go Beaver A.I, we're so confident you'll love the jaw-dropping ads and content our AI churns out, we're
              putting our money where our mouth is!
            </p>
            <p className="text-gray-700 mb-4">
              If your ads, social media posts and content don't make you feel like a marketing wizard within 30 days,
              just let us know.
            </p>
            <p className="text-gray-700">
              We'll give you a full refund—no hassle, no hard feelings, and no awkward goodbyes. Go ahead, put Go Beaver
              A.I to the test! If it doesn't deliver your dream ads, we'll happily return every penny.
            </p>
          </div>
        </div>
      </div>

      {/* Main CTA */}
      <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-8 md:p-12 text-white">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Get Instant Access To Go Beaver AI</h2>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-8">
              <div className="flex flex-col md:flex-row items-center justify-center gap-8">
                <div className="text-left">
                  <p className="text-white/80 text-lg">Regular Bundle Price</p>
                  <p className="text-3xl font-bold text-white/70 line-through">$497</p>
                  <p className="text-sm text-green-300 font-medium mt-1">Use Coupon SAVE200</p>
                </div>
                <div className="text-center">
                  <p className="text-white/80 text-lg">Your Price Today</p>
                  <p className="text-4xl font-bold text-white">Just $297</p>
                  <p className="text-sm text-white/80 font-medium mt-1">One Time Payment!</p>
                </div>
              </div>
            </div>

            <Link
              href="https://jvz8.com/c/3297023/418161/"
              className="inline-block bg-white text-blue-700 hover:bg-blue-50 px-8 py-4 rounded-lg text-lg font-medium transition-all duration-300 transform hover:scale-105 flex items-center gap-2 mx-auto"
            >
              Get Instant Access
              <ArrowRight className="h-5 w-5" />
            </Link>

            <p className="mt-4 text-white/80">No Monthly Fees EVER - One Time Payment</p>
            <p className="mt-6 text-sm opacity-80">Secure checkout. 30-day money-back guarantee.</p>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="mt-16">
        <h2 className="text-3xl font-bold mb-8 text-center">Frequently Asked Questions</h2>

        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-3">Can I not just use Chat GPT or Manus for this?</h3>
            <p className="text-gray-700">
              While Chat GPT is very helpful it does not research winning ads, let you preview as if it was in FB,
              Google, Insta Interface etc. With Go Beaver A.I we have done the prompt engineering to get you results
              fast, saving you hours of trial and error.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-3">What ways can I generate sales with this?</h3>
            <p className="text-gray-700">
              You can literally spy on your best competitors ads and recreate for yourself in seconds! So easy to use.
              It can work perfectly for affiliate marketing, local business owners & Agencies.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-3">What industries does it work in?</h3>
            <p className="text-gray-700">
              The simple answer…. EVERYTHING! We've tested this in 100's of industries already.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-3">Is this a monthly or one time fee?</h3>
            <p className="text-gray-700">
              The pricing will be above. You have landed on our best offer page so please take action today to get in at
              the best deal! This is normally a monthly cost but during the opening launch special you can get one time
              fee access - pay once.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-3">What type of content can I create?</h3>
            <p className="text-gray-700">
              FB, Instagram, Google Search, Google Banner, Tik Tok Scripts, Linked In, YouTube Video Scripts, Organic
              Social Media, Emails and much more!
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
