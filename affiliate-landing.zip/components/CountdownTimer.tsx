"use client"

import { useState, useEffect } from "react"

export default function CountdownTimer() {
  // Set the countdown to 24 hours from now
  const [timeLeft, setTimeLeft] = useState({
    hours: 11,
    minutes: 25,
    seconds: 7,
  })

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        let { hours, minutes, seconds } = prevTime

        if (seconds > 0) {
          seconds -= 1
        } else {
          seconds = 59
          if (minutes > 0) {
            minutes -= 1
          } else {
            minutes = 59
            if (hours > 0) {
              hours -= 1
            } else {
              // Reset to 24 hours when countdown reaches zero
              hours = 23
              minutes = 59
              seconds = 59
            }
          }
        }

        return { hours, minutes, seconds }
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="flex justify-center gap-4 mt-2">
      <div className="flex flex-col items-center">
        <div className="bg-blue-600 text-white text-2xl font-bold rounded-md w-14 h-14 flex items-center justify-center">
          {String(timeLeft.hours).padStart(2, "0")}
        </div>
        <span className="text-xs mt-1 text-gray-600">Hours</span>
      </div>
      <div className="flex flex-col items-center">
        <div className="bg-blue-600 text-white text-2xl font-bold rounded-md w-14 h-14 flex items-center justify-center">
          {String(timeLeft.minutes).padStart(2, "0")}
        </div>
        <span className="text-xs mt-1 text-gray-600">Minutes</span>
      </div>
      <div className="flex flex-col items-center">
        <div className="bg-blue-600 text-white text-2xl font-bold rounded-md w-14 h-14 flex items-center justify-center">
          {String(timeLeft.seconds).padStart(2, "0")}
        </div>
        <span className="text-xs mt-1 text-gray-600">Seconds</span>
      </div>
    </div>
  )
}
