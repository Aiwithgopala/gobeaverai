import Image from "next/image"

export default function Footer() {
  return (
    <footer className="bg-white border-t py-8 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-center mb-6">
          <Image
            src="https://bitfan-id.s3.ap-northeast-1.amazonaws.com/store/c284adcd67b6be837474772e8d307eea.png"
            alt="Go Beaver AI Logo"
            width={140}
            height={35}
            className="h-8 w-auto"
          />
        </div>

        <div className="text-center text-sm text-gray-500 space-y-4">
          <p>&copy; 2025 Go Beaver AI Webinar Bundle - All Rights Reserved.</p>
          <p className="max-w-3xl mx-auto">
            Disclaimer: Please note that this product does not provide any guarantee of income or success. The results
            achieved by the product owner or any other individuals mentioned are not indicative of future success or
            earnings. This website is not affiliated with FaceBook or any of its associated entities.
          </p>
          <p className="max-w-3xl mx-auto">
            We want to clarify that JVZoo serves as the retailer for the products featured on this site. JVZoo® is a
            registered trademark of BBC Systems Inc., a Florida corporation located at 1809 E. Broadway Street, Suite
            125, Oviedo, FL 32765, USA, and is used with permission.
          </p>
        </div>
      </div>
    </footer>
  )
}
