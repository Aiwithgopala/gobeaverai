"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import {
  ArrowRight,
  Check,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Star,
  Clock,
  Zap,
  DollarSign,
  MousePointerClick,
  Copy,
  CheckCircle2,
} from "lucide-react"

export default function LandingPage() {
  // State for sticky header
  const [isScrolled, setIsScrolled] = useState(false)

  // State for countdown timer
  const [timeLeft, setTimeLeft] = useState({
    hours: 11,
    minutes: 25,
    seconds: 7,
  })

  // State for FAQ accordion
  const [openFaq, setOpenFaq] = useState<number | null>(null)

  // State for feature tabs
  const [activeTab, setActiveTab] = useState(0)

  // State for sticky CTA
  const [showStickyCta, setShowStickyCta] = useState(false)

  // State for copy coupon code
  const [couponCopied, setCouponCopied] = useState(false)

  // Refs for sections (for scroll animations)
  const heroRef = useRef<HTMLDivElement>(null)
  const featuresRef = useRef<HTMLDivElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)

  // Handle scroll events
  useEffect(() => {
    const handleScroll = () => {
      // For sticky header
      setIsScrolled(window.scrollY > 10)

      // For sticky CTA
      setShowStickyCta(window.scrollY > 800)

      // For scroll animations (handled by Intersection Observer below)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        let { hours, minutes, seconds } = prevTime

        if (seconds > 0) {
          seconds -= 1
        } else {
          seconds = 59
          if (minutes > 0) {
            minutes -= 1
          } else {
            minutes = 59
            if (hours > 0) {
              hours -= 1
            } else {
              // Reset to 24 hours when countdown reaches zero
              hours = 23
              minutes = 59
              seconds = 59
            }
          }
        }

        return { hours, minutes, seconds }
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // Copy coupon code function
  const copyCouponCode = () => {
    navigator.clipboard.writeText("SAVE200")
    setCouponCopied(true)
    setTimeout(() => setCouponCopied(false), 2000)
  }

  // Toggle FAQ item
  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index)
  }

  // Features data
  const features = [
    {
      title: "Go Beaver A.I - UNLIMITED",
      value: "$2394",
      description: "The Ultimate Ads, Social Media & Email Content Generation Tool On the Planet",
      image:
        "https://images.clickfunnels.com/cdn-cgi/image/width=2600,fit=scale-down,f=auto,q=80/https://statics.myclickfunnels.com/workspace/jQQdMW/image/13925130/file/63e5ba6a451382926771b5132b7fb4f2.png",
      platforms: [
        "FB Ads",
        "Instagram",
        "TikTok",
        "YouTube",
        "Google Search",
        "Google Banner",
        "LinkedIn",
        "Email Marketing",
      ],
      icon: <Zap className="w-6 h-6" />,
    },
    {
      title: "Go Beaver Super Spy",
      value: "$297",
      description: "Spy direct from FB & TikTok ads library with chrome extension",
      image:
        "https://images.clickfunnels.com/cdn-cgi/image/width=2600,fit=scale-down,f=auto,q=80/https://statics.myclickfunnels.com/workspace/jQQdMW/image/13925190/file/03e895ca6248ec357b17e2c545e4b73b.png",
      benefits: [
        "Spy Direct On Facebook Ads Library On Your Competitors",
        "Re Create Your Own with A.I In 1 Click",
        "Spy Direct on TikTok Ads Library",
        "Create A Month of Organic Social Media Posts In Minutes",
      ],
      steps: [
        "Spy on Any Keyword/Advertiser on Facebook Library",
        "Spy on Viral, Winning TikTok Video Ads And Re Create Your Own",
        "Publish your content to generate traffic, leads and sales!",
      ],
      icon: <MousePointerClick className="w-6 h-6" />,
    },
    {
      title: "Go Beaver PRO Edition",
      value: "$297",
      description: "Included A.I Geniuses, seasonal promos and Social Beaver Organic social media",
      image:
        "https://images.clickfunnels.com/cdn-cgi/image/width=2600,fit=scale-down,f=auto,q=80/https://statics.myclickfunnels.com/workspace/jQQdMW/image/13925208/file/9e4b00457ca386dd39cc4ee6bf593309.png",
      proFeatures: [
        {
          title: "12 A.I Geniuses",
          description: "Write Ads & Social Posts Like Your Favorite Guru or Expert",
          geniuses: [
            "Funnel Ad Genius",
            "Direct Response Ad Genius",
            "Entrepreneur",
            "Business Coaching",
            "Super Affiliate Ad Genius",
            "Real Estate Genius",
          ],
        },
        {
          title: "Instant Seasonal 'Done For You' Campaigns",
          description:
            'Want to run a promotion for the big "money spending" periods of the year but never seem to have enough time?',
        },
        {
          title: "'Social Beaver A.I'",
          description:
            "Create Amazing Organic Social Media With Social Beaver. In a few clicks you instantly can create full social media campaigns.",
        },
      ],
      icon: <Star className="w-6 h-6" />,
    },
    {
      title: "Go Beaver Super Affiliate DFY",
      value: "$297",
      description: "Includes 25 DFY Super affiliate campaigns",
      image:
        "https://images.clickfunnels.com/cdn-cgi/image/width=2600,fit=scale-down,f=auto,q=80/https://statics.myclickfunnels.com/workspace/jQQdMW/image/13925314/file/a0bb9d33fd0a8ba31c91b175c61303d0.png",
      campaignIncludes: [
        "Expertly Crafted Facebook Ads",
        "Engaging Landing Page Copy",
        "Short-Style Promo Video",
        "High-Converting YouTube Scripts",
        "Attention-Grabbing TikTok Scripts",
        "Powerful Email Follow-Up Sequence",
      ],
      icon: <DollarSign className="w-6 h-6" />,
    },
  ]

  // FAQ data
  const faqs = [
    {
      question: "Can I not just use Chat GPT or Manus for this?",
      answer:
        "While Chat GPT is very helpful it does not research winning ads, let you preview as if it was in FB, Google, Insta Interface etc. With Go Beaver A.I we have done the prompt engineering to get you results fast, saving you hours of trial and error.",
    },
    {
      question: "What ways can I generate sales with this?",
      answer:
        "You can literally spy on your best competitors ads and recreate for yourself in seconds! So easy to use. It can work perfectly for affiliate marketing, local business owners & Agencies.",
    },
    {
      question: "What industries does it work in?",
      answer: "The simple answer…. EVERYTHING! We've tested this in 100's of industries already.",
    },
    {
      question: "Is this a monthly or one time fee?",
      answer:
        "The pricing will be above. You have landed on our best offer page so please take action today to get in at the best deal! This is normally a monthly cost but during the opening launch special you can get one time fee access - pay once.",
    },
    {
      question: "What type of content can I create?",
      answer:
        "FB, Instagram, Google Search, Google Banner, Tik Tok Scripts, Linked In, YouTube Video Scripts, Organic Social Media, Emails and much more!",
    },
  ]

  // Testimonials data
  const testimonials = [
    {
      name: "Michael T.",
      role: "Digital Marketer",
      image: "/placeholder.svg?height=80&width=80",
      text: "Go Beaver AI has completely transformed my affiliate marketing business. I'm now generating $1,200+ per week with campaigns that took me minutes to set up!",
    },
    {
      name: "Sarah J.",
      role: "E-commerce Store Owner",
      image: "/placeholder.svg?height=80&width=80",
      text: "The Super Spy feature is incredible! I was able to analyze my competitors' best ads and create even better versions for my store. My ROAS has doubled in just 3 weeks.",
    },
    {
      name: "David L.",
      role: "Agency Owner",
      image: "/placeholder.svg?height=80&width=80",
      text: "I'm now offering AI ad creation as a service to my clients. Go Beaver AI has allowed me to scale my agency while delivering better results in less time.",
    },
  ]

  return (
    <div className="bg-gradient-to-b from-gray-50 to-gray-100 text-gray-800 min-h-screen flex flex-col">
      {/* Sticky Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "bg-white shadow-md py-2" : "bg-white/95 py-3"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center">
            <Image
              src="https://bitfan-id.s3.ap-northeast-1.amazonaws.com/store/c284adcd67b6be837474772e8d307eea.png"
              alt="Go Beaver AI Logo"
              width={160}
              height={40}
              className="h-10 w-auto"
            />
          </div>
          <Link
            href="https://jvz8.com/c/3297023/418161/"
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors duration-300 font-medium"
          >
            Get Bundle Now
          </Link>
        </div>
      </header>

      {/* Sticky CTA Button */}
      <AnimatePresence>
        {showStickyCta && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-4 right-4 z-50"
          >
            <Link
              href="https://jvz8.com/c/3297023/418161/"
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium shadow-lg flex items-center gap-2"
            >
              Get Bundle Now
              <ArrowRight className="h-5 w-5" />
            </Link>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="pt-24 flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Section */}
          <section className="py-12 md:py-20" ref={heroRef}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center max-w-4xl mx-auto"
            >
              <div className="mb-8 bg-gradient-to-r from-blue-100 to-green-100 p-4 rounded-lg inline-block shadow-md">
                <p className="text-blue-800 font-medium">
                  Nice! You've found the Exclusive Webinar Bundle Page - Save $200!
                </p>
                <div className="mt-2">
                  <p className="text-gray-700 font-medium">Hurry - Coupon 'SAVE200' Expires Midnight P.S.T</p>

                  {/* Countdown Timer */}
                  <div className="flex justify-center gap-4 mt-2">
                    <div className="flex flex-col items-center">
                      <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white text-2xl font-bold rounded-md w-14 h-14 flex items-center justify-center shadow-md">
                        {String(timeLeft.hours).padStart(2, "0")}
                      </div>
                      <span className="text-xs mt-1 text-gray-600">Hours</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white text-2xl font-bold rounded-md w-14 h-14 flex items-center justify-center shadow-md">
                        {String(timeLeft.minutes).padStart(2, "0")}
                      </div>
                      <span className="text-xs mt-1 text-gray-600">Minutes</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white text-2xl font-bold rounded-md w-14 h-14 flex items-center justify-center shadow-md">
                        {String(timeLeft.seconds).padStart(2, "0")}
                      </div>
                      <span className="text-xs mt-1 text-gray-600">Seconds</span>
                    </div>
                  </div>
                </div>
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-green-600">
                Spy, Copy & Clone Winning Ads That Earn $2,472/Day
              </h1>
              <p className="text-lg md:text-xl text-gray-700 mb-8 max-w-3xl mx-auto">
                Using This NEW A.I Technology To Transform Your Marketing Campaigns
              </p>

              {/* Price Box */}
              <motion.div
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white shadow-xl rounded-xl p-6 mb-8 border border-gray-200"
              >
                <div className="flex flex-col md:flex-row items-center justify-center gap-8">
                  <div className="text-left">
                    <p className="text-gray-500 text-lg">Regular Bundle Price</p>
                    <p className="text-3xl font-bold text-gray-400 line-through">$497</p>
                    <div className="flex items-center mt-1 gap-2">
                      <p className="text-sm text-green-600 font-medium">Use Coupon SAVE200</p>
                      <button
                        onClick={copyCouponCode}
                        className="text-blue-500 hover:text-blue-700 transition-colors"
                        title="Copy coupon code"
                      >
                        {couponCopied ? <CheckCircle2 className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                  <div className="text-center relative">
                    <div className="absolute -top-10 -right-10 bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full transform rotate-12">
                      SAVE $200!
                    </div>
                    <p className="text-gray-500 text-lg">Your Price Today</p>
                    <p className="text-4xl font-bold text-green-600">Just $297</p>
                    <p className="text-sm text-gray-600 font-medium mt-1">One Time Payment!</p>
                  </div>
                </div>
              </motion.div>

              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Link
                  href="https://jvz8.com/c/3297023/418161/"
                  className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-8 py-4 rounded-lg text-lg font-medium transition-all duration-300 shadow-lg flex items-center gap-2 w-full sm:w-auto justify-center mx-auto"
                >
                  Get the Exclusive Webinar Bundle Now
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </motion.div>
              <p className="mt-4 text-gray-600 font-medium flex items-center justify-center gap-1">
                <Clock className="h-4 w-4" />
                No Monthly Fees EVER - One Time Payment
              </p>
            </motion.div>
          </section>

          {/* Features Section */}
          <section className="py-16" ref={featuresRef}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Your Exclusive Webinar Bundle Includes 4 Upgrades</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">TOTAL VALUE $3394!</p>
            </motion.div>

            {/* Feature Tabs */}
            <div className="mb-8">
              <div className="flex flex-wrap justify-center gap-2 mb-8">
                {features.map((feature, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveTab(index)}
                    className={`px-4 py-2 rounded-full flex items-center gap-2 transition-all ${
                      activeTab === index
                        ? "bg-blue-600 text-white shadow-md"
                        : "bg-white text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    {feature.icon}
                    <span className="hidden md:inline">{feature.title}</span>
                  </button>
                ))}
              </div>

              {/* Feature Content */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className="bg-white rounded-xl shadow-lg overflow-hidden"
                >
                  <div className="p-6 md:p-8">
                    <div className="flex flex-col md:flex-row gap-8">
                      <div className="md:w-1/3">
                        <div className="relative h-64 rounded-lg overflow-hidden shadow-md">
                          <Image
                            src={features[activeTab].image || "/placeholder.svg"}
                            alt={features[activeTab].title}
                            fill
                            className="object-cover transition-transform duration-700 hover:scale-110"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                            <div className="p-4 w-full">
                              <div className="flex justify-between items-end">
                                <h3 className="text-white font-bold text-xl">{features[activeTab].title}</h3>
                                <span className="bg-green-500 text-white px-2 py-1 rounded text-sm font-bold">
                                  Value: {features[activeTab].value}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="md:w-2/3">
                        <div className="flex items-center mb-4">
                          <span className="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">
                            Upgrade #{activeTab + 1}
                          </span>
                          <h3 className="text-2xl font-bold ml-3">{features[activeTab].title}</h3>
                        </div>
                        <p className="text-gray-600 mb-6">{features[activeTab].description}</p>

                        {/* Conditional content based on active tab */}
                        {activeTab === 0 && (
                          <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                            <h5 className="font-medium mb-3">Create Content For Multiple Platforms:</h5>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                              {features[0].platforms.map((platform, idx) => (
                                <motion.div
                                  key={idx}
                                  whileHover={{ scale: 1.05, backgroundColor: "#EFF6FF" }}
                                  className="bg-white p-3 rounded-md text-center shadow-sm"
                                >
                                  {platform}
                                </motion.div>
                              ))}
                            </div>
                          </div>
                        )}

                        {activeTab === 1 && (
                          <>
                            <div className="space-y-3 mb-6">
                              {features[1].benefits.map((benefit, idx) => (
                                <div key={idx} className="flex items-start">
                                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                                  <p>{benefit}</p>
                                </div>
                              ))}
                            </div>

                            <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                              <h5 className="font-medium mb-3">Simple 3-Step Process:</h5>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                {features[1].steps.map((step, idx) => (
                                  <motion.div
                                    key={idx}
                                    whileHover={{ scale: 1.03 }}
                                    className="bg-white p-4 rounded-md shadow-sm"
                                  >
                                    <div className="font-bold text-blue-600 mb-2">Step {idx + 1}</div>
                                    <p className="text-sm">{step}</p>
                                  </motion.div>
                                ))}
                              </div>
                            </div>
                          </>
                        )}

                        {activeTab === 2 && (
                          <div className="space-y-6">
                            {features[2].proFeatures.map((feature, idx) => (
                              <motion.div
                                key={idx}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.1 }}
                              >
                                <h4 className="text-lg font-semibold mb-2">
                                  Pro Feature #{idx + 1} - {feature.title}
                                </h4>
                                <p className="text-gray-700 mb-3">{feature.description}</p>

                                {idx === 0 && feature.geniuses && (
                                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                    {feature.geniuses.map((genius, i) => (
                                      <motion.div
                                        key={i}
                                        whileHover={{ scale: 1.05, backgroundColor: "#EFF6FF" }}
                                        className="bg-gray-50 p-3 rounded-md text-sm"
                                      >
                                        {genius}
                                      </motion.div>
                                    ))}
                                  </div>
                                )}
                              </motion.div>
                            ))}
                          </div>
                        )}

                        {activeTab === 3 && (
                          <>
                            <h4 className="text-lg font-semibold mb-3">25 Super Affiliate Campaigns</h4>
                            <p className="text-gray-700 mb-4">
                              Point, Click and Launch Campaigns Within Seconds. With Go Beaver's Super Affiliate
                              Done-For-You 25-Campaign Package, you take a giant leap ahead by having 25 hot, converting
                              campaigns pre-loaded directly into your Beaver A.I account.
                            </p>

                            <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                              <h5 className="font-medium mb-3">What You Get Inside Each Campaign:</h5>
                              <div className="grid grid-cols-2 gap-3">
                                {features[3].campaignIncludes.map((item, idx) => (
                                  <motion.div key={idx} whileHover={{ scale: 1.02 }} className="flex items-start">
                                    <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                                    <p className="text-sm">{item}</p>
                                  </motion.div>
                                ))}
                              </div>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </section>

          {/* Testimonials Section */}
          <section className="py-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-center mb-10"
            >
              <h2 className="text-3xl font-bold mb-4">What Our Customers Are Saying</h2>
              <p className="text-gray-600">Real results from real Go Beaver AI users</p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                  viewport={{ once: true }}
                  whileHover={{ y: -5 }}
                  className="bg-white p-6 rounded-xl shadow-lg"
                >
                  <div className="flex items-center mb-4">
                    <div className="mr-4">
                      <Image
                        src={testimonial.image || "/placeholder.svg"}
                        alt={testimonial.name}
                        width={50}
                        height={50}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h4 className="font-bold">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.role}</p>
                    </div>
                  </div>
                  <div className="flex mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700">{testimonial.text}</p>
                </motion.div>
              ))}
            </div>
          </section>

          {/* Call To Action Section */}
          <section className="py-16" ref={ctaRef}>
            {/* Money Back Guarantee */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-white rounded-xl shadow-lg overflow-hidden mb-12 p-6 md:p-8"
            >
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="md:w-1/4 flex justify-center">
                  <motion.div
                    whileHover={{ scale: 1.05, rotate: 5 }}
                    className="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center"
                  >
                    <ShieldCheck className="w-16 h-16 text-blue-600" />
                  </motion.div>
                </div>
                <div className="md:w-3/4">
                  <h3 className="text-2xl font-bold mb-4">
                    Your Covered By Our 'No Quibble' 30 Day Money Back Guarantee
                  </h3>
                  <p className="text-gray-700 mb-4">
                    At Go Beaver A.I, we're so confident you'll love the jaw-dropping ads and content our AI churns out,
                    we're putting our money where our mouth is!
                  </p>
                  <p className="text-gray-700 mb-4">
                    If your ads, social media posts and content don't make you feel like a marketing wizard within 30
                    days, just let us know.
                  </p>
                  <p className="text-gray-700">
                    We'll give you a full refund—no hassle, no hard feelings, and no awkward goodbyes. Go ahead, put Go
                    Beaver A.I to the test! If it doesn't deliver your dream ads, we'll happily return every penny.
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Main CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl shadow-xl overflow-hidden"
            >
              <div className="p-8 md:p-12 text-white">
                <div className="max-w-3xl mx-auto text-center">
                  <h2 className="text-3xl md:text-4xl font-bold mb-6">Get Instant Access To Go Beaver AI</h2>

                  <motion.div whileHover={{ scale: 1.02 }} className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-8">
                    <div className="flex flex-col md:flex-row items-center justify-center gap-8">
                      <div className="text-left">
                        <p className="text-white/80 text-lg">Regular Bundle Price</p>
                        <p className="text-3xl font-bold text-white/70 line-through">$497</p>
                        <p className="text-sm text-green-300 font-medium mt-1">Use Coupon SAVE200</p>
                      </div>
                      <div className="text-center">
                        <p className="text-white/80 text-lg">Your Price Today</p>
                        <p className="text-4xl font-bold text-white">Just $297</p>
                        <p className="text-sm text-white/80 font-medium mt-1">One Time Payment!</p>
                      </div>
                    </div>
                  </motion.div>

                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Link
                      href="https://jvz8.com/c/3297023/418161/"
                      className="inline-block bg-white text-blue-700 hover:bg-blue-50 px-8 py-4 rounded-lg text-lg font-medium transition-all duration-300 transform shadow-lg flex items-center gap-2 mx-auto"
                    >
                      Get Instant Access
                      <ArrowRight className="h-5 w-5" />
                    </Link>
                  </motion.div>

                  <p className="mt-4 text-white/80">No Monthly Fees EVER - One Time Payment</p>
                  <p className="mt-6 text-sm opacity-80">Secure checkout. 30-day money-back guarantee.</p>
                </div>
              </div>
            </motion.div>

            {/* FAQ Section */}
            <div className="mt-16">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
              >
                <h2 className="text-3xl font-bold mb-8 text-center">Frequently Asked Questions</h2>
              </motion.div>

              <div className="space-y-4">
                {faqs.map((faq, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                    viewport={{ once: true }}
                    className="bg-white rounded-lg shadow-md overflow-hidden"
                  >
                    <button
                      onClick={() => toggleFaq(index)}
                      className="w-full px-6 py-4 text-left flex justify-between items-center focus:outline-none"
                    >
                      <h3 className="text-xl font-semibold">{faq.question}</h3>
                      {openFaq === index ? (
                        <ChevronUp className="h-5 w-5 text-gray-500" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-gray-500" />
                      )}
                    </button>
                    <AnimatePresence>
                      {openFaq === index && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="overflow-hidden"
                        >
                          <div className="px-6 pb-4 text-gray-700">{faq.answer}</div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </div>
      </main>

      <footer className="bg-white border-t py-8 md:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center mb-6">
            <Image
              src="https://bitfan-id.s3.ap-northeast-1.amazonaws.com/store/c284adcd67b6be837474772e8d307eea.png"
              alt="Go Beaver AI Logo"
              width={140}
              height={35}
              className="h-8 w-auto"
            />
          </div>

          <div className="text-center text-sm text-gray-500 space-y-4">
            <p>&copy; 2025 Go Beaver AI Webinar Bundle - All Rights Reserved.</p>
            <p className="max-w-3xl mx-auto">
              Disclaimer: Please note that this product does not provide any guarantee of income or success. The results
              achieved by the product owner or any other individuals mentioned are not indicative of future success or
              earnings. This website is not affiliated with FaceBook or any of its associated entities.
            </p>
            <p className="max-w-3xl mx-auto">
              We want to clarify that JVZoo serves as the retailer for the products featured on this site. JVZoo® is a
              registered trademark of BBC Systems Inc., a Florida corporation located at 1809 E. Broadway Street, Suite
              125, Oviedo, FL 32765, USA, and is used with permission.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
